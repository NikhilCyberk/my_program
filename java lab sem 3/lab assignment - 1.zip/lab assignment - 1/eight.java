import java.util.Scanner;

public class eight {
    public static void main(string[] args) {
        Scanner sc = new Scanner(system.in);
        String s = New sc.next();
        int max = 0;

    }
}
